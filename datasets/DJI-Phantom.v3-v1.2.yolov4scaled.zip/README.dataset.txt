# undefined > V1.2
https://public.roboflow.ai/object-detection/undefined

Provided by undefined
License: CC BY 4.0

undefined
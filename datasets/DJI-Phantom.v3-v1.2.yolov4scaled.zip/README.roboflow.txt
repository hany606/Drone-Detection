
DJI-Phantom - v3 V1.2
==============================

This dataset was exported via roboflow.ai on October 6, 2021 at 8:55 PM GMT

It includes 777 images.
Drones are annotated in Scaled-YOLOv4 format.

The following pre-processing was applied to each image:
* Auto-orientation of pixel data (with EXIF-orientation stripping)
* Resize to 416x416 (Stretch)

The following augmentation was applied to create 3 versions of each source image:
* Random rotation of between -20 and +20 degrees
* Random shear of between -15° to +15° horizontally and -15° to +15° vertically
* Random brigthness adjustment of between -20 and +20 percent
* Random Gaussian blur of between 0 and 5 pixels
* Salt and pepper noise was applied to 3 percent of pixels

The following transformations were applied to the bounding boxes of each image:
* Randomly crop between 4 and 19 percent of the bounding box


